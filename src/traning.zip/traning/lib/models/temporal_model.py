"""用分层 GRUCell 实现可流式调用的因果动作与候选选择模型。"""

from __future__ import annotations

import torch
from torch import nn

from traning.lib.models.outputs import ActionPrediction
from traning.lib.models.smet import maybe_sparse_linear


class CausalTemporalModel(nn.Module):
    """支持逐帧流式推理的因果 GRU 动作头。"""

    def __init__(
        self,
        *,
        input_size: int,
        hidden_size: int = 256,
        layers: int = 2,
        candidate_slots: int = 64,
        action_classes: int = 4,
        smet_enabled: bool = False,
        smet_sparsity: float = 0.50,
        smet_update_interval: int = 16,
        smet_min_density: float = 0.05,
    ) -> None:
        super().__init__()
        if min(input_size, hidden_size, layers, candidate_slots, action_classes) <= 0:
            raise ValueError("temporal model dimensions must be positive")
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.layers = layers
        self.cells = nn.ModuleList(
            nn.GRUCell(input_size if layer == 0 else hidden_size, hidden_size)
            for layer in range(layers)
        )
        sparse_head = {
            "enabled": smet_enabled,
            "sparsity": smet_sparsity,
            "update_interval": smet_update_interval,
            "min_density": smet_min_density,
        }
        self.action_head = maybe_sparse_linear(hidden_size, action_classes, **sparse_head)
        self.candidate_head = maybe_sparse_linear(hidden_size, candidate_slots, **sparse_head)
        self.xy_head = maybe_sparse_linear(hidden_size, 2, **sparse_head)
        self.time_head = maybe_sparse_linear(hidden_size, 1, **sparse_head)

    def initial_state(
        self,
        batch_size: int,
        device: torch.device | str,
        *,
        dtype: torch.dtype | None = None,
    ) -> torch.Tensor:
        """创建 ``layers x batch x hidden`` 隐状态，与模型设备/精度一致。"""

        if batch_size <= 0:
            raise ValueError("batch_size must be positive")
        parameter = next(self.parameters())
        state_dtype = dtype or parameter.dtype
        return torch.zeros(
            self.layers,
            batch_size,
            self.hidden_size,
            device=device,
            dtype=state_dtype,
        )

    def step(
        self,
        current_features: torch.Tensor,
        previous_state: torch.Tensor,
    ) -> tuple[ActionPrediction, torch.Tensor]:
        """消费一个 BF 帧特征和上一状态，不读取任何未来帧。"""

        if current_features.ndim != 2:
            raise ValueError("current_features must use BF layout")
        if previous_state.shape[:2] != (self.layers, current_features.shape[0]):
            raise ValueError("previous_state shape must be layers x batch x hidden")
        if previous_state.shape[2] != self.hidden_size:
            raise ValueError("previous_state hidden size mismatch")
        layer_input = current_features
        next_states = []
        # 显式逐层 GRUCell 让同一 step API 可直接复用于在线决策。
        for layer, cell in enumerate(self.cells):
            hidden = cell(layer_input, previous_state[layer])
            next_states.append(hidden)
            layer_input = hidden
        next_state = torch.stack(next_states, dim=0)
        xy = self.xy_head(layer_input)
        prediction = ActionPrediction(
            action_logits=self.action_head(layer_input),
            selected_candidate_logits=self.candidate_head(layer_input),
            x=xy[:, :1],
            y=xy[:, 1:2],
            time_offset_ms=self.time_head(layer_input),
            next_hidden_state=next_state,
        )
        return prediction, next_state

    def forward(
        self, sequence: torch.Tensor
    ) -> tuple[list[ActionPrediction], torch.Tensor]:
        """按 ``T x B x F`` 时间顺序重复调用因果 step。"""

        if sequence.ndim != 3:
            raise ValueError("sequence must use TBF layout")
        _, batch_size, _ = sequence.shape
        state = self.initial_state(batch_size, sequence.device, dtype=sequence.dtype)
        outputs: list[ActionPrediction] = []
        for frame_features in sequence:
            output, state = self.step(frame_features, state)
            outputs.append(output)
        return outputs, state


__all__ = ["CausalTemporalModel"]
