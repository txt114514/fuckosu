"""加载时序模型和候选缓存，逐窗口导出动作、候选与坐标决策。"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F

from traning.conf import Settings
from traning.core.temporal import (
    ACTION_NAMES,
    TemporalCandidateWindowDataset,
    TemporalWindow,
)
from traning.lib.models import CausalTemporalModel
from traning.lib.runtime import (
    CudaRuntimeConfig,
    autocast_context,
    configure_torch_runtime,
    enforce_runtime_memory_budget,
    module_to_device,
    tensor_to_device,
)


DECISION_OUTPUT_VERSION = "temporal-decision-v1"


@dataclass(frozen=True)
class TemporalDecisionRunResult:
    output_dir: Path
    manifest_path: Path
    decisions_path: Path
    checkpoint_path: Path
    device: str
    frames: int
    sequence_length: int
    candidate_slots: int

    def as_dict(self) -> dict[str, Any]:
        return {
            "output_dir": self.output_dir,
            "manifest_path": self.manifest_path,
            "decisions_path": self.decisions_path,
            "checkpoint_path": self.checkpoint_path,
            "device": self.device,
            "frames": self.frames,
            "sequence_length": self.sequence_length,
            "candidate_slots": self.candidate_slots,
        }


def run_temporal_decision(
    settings: Settings,
    *,
    cache_dir: Path,
    checkpoint_path: Path,
    output_dir: Path,
    device: torch.device,
) -> TemporalDecisionRunResult:
    checkpoint = _load_checkpoint(checkpoint_path, device=device)
    model_config = checkpoint["model_config"]
    sequence_length = int(checkpoint["sequence_length"])
    candidate_slots = int(model_config["candidate_slots"])
    dataset = TemporalCandidateWindowDataset.from_cache_dir(
        cache_dir,
        sequence_length=sequence_length,
        candidate_slots=candidate_slots,
    )
    model = CausalTemporalModel(**model_config)
    model.load_state_dict(checkpoint["model_state"])
    enforce_runtime_memory_budget(
        device=device,
        max_vram_gib=settings.memory.max_vram_gib,
        reserve_vram_gib=settings.memory.reserve_vram_gib,
        max_ram_gib=settings.memory.max_ram_gib,
        reserve_ram_gib=settings.memory.reserve_ram_gib,
    )
    runtime_state = configure_torch_runtime(
        device=device,
        amp_dtype=settings.memory.amp_dtype,
        runtime=CudaRuntimeConfig(
            allow_tf32=settings.memory.allow_tf32,
            cudnn_benchmark=settings.memory.cudnn_benchmark,
            matmul_float32_precision=settings.memory.matmul_float32_precision,
            channels_last=False,
        ),
    )
    model = module_to_device(model, device, channels_last=False)
    model.eval()
    output_dir.mkdir(parents=True, exist_ok=True)
    decisions_path = output_dir / "decisions.jsonl"
    frames = 0
    diagnostics_rows: list[dict[str, Any]] = []
    with decisions_path.open("w", encoding="utf-8") as handle:
        with torch.no_grad(), autocast_context(device, runtime_state.amp_dtype):
            for window in dataset:
                batch = tensor_to_device(
                    window.features.unsqueeze(1),
                    device,
                    channels_last=False,
                    non_blocking=False,
                )
                outputs, _ = model(batch)
                for frame_index, output in enumerate(outputs):
                    # 定长窗口尾部用零填充；frame_mask 防止把填充槽序列化为真实决策。
                    if not bool(window.frame_mask[frame_index]):
                        continue
                    row = _decision_row(window, frame_index, output)
                    diagnostics_rows.append(row["diagnostics"])
                    handle.write(json.dumps(row, ensure_ascii=False) + "\n")
                    frames += 1
    manifest_path = output_dir / "manifest.json"
    manifest = {
        "version": DECISION_OUTPUT_VERSION,
        "frames": frames,
        "checkpoint": str(checkpoint_path),
        "candidate_cache": str(cache_dir),
        "decisions": decisions_path.name,
        "device": str(device),
        "sequence_length": sequence_length,
        "candidate_slots": candidate_slots,
        "diagnostics": _decision_diagnostics(diagnostics_rows),
    }
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return TemporalDecisionRunResult(
        output_dir=output_dir,
        manifest_path=manifest_path,
        decisions_path=decisions_path,
        checkpoint_path=checkpoint_path,
        device=str(device),
        frames=frames,
        sequence_length=sequence_length,
        candidate_slots=candidate_slots,
    )


def _load_checkpoint(
    checkpoint_path: Path,
    *,
    device: torch.device,
) -> Mapping[str, Any]:
    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
    if not isinstance(checkpoint, Mapping):
        raise ValueError("temporal checkpoint must be a mapping")
    if checkpoint.get("version") != DECISION_OUTPUT_VERSION:
        raise ValueError(
            f"unsupported temporal checkpoint version: {checkpoint.get('version')!r}"
        )
    if not isinstance(checkpoint.get("model_config"), Mapping):
        raise ValueError("temporal checkpoint missing model_config")
    if "model_state" not in checkpoint:
        raise ValueError("temporal checkpoint missing model_state")
    return checkpoint


def _decision_row(
    window: TemporalWindow,
    frame_index: int,
    output,
) -> dict[str, Any]:
    """将单帧时序模型输出序列化为坐标空间明确的决策记录。

    ``model_input_normalized`` 表示相对于完整输入帧宽高的归一化坐标，
    不是相对于 osu! 512x384 playfield 的归一化坐标。
    """
    action_probs = F.softmax(output.action_logits[0], dim=0).detach().cpu()
    top_probs, _ = torch.topk(action_probs, k=min(2, action_probs.numel()))
    action_id = int(action_probs.argmax().item())
    candidate_logits = output.selected_candidate_logits[0].detach().cpu().clone()
    mask = window.candidate_mask[frame_index]
    if bool(mask.any()):
        candidate_logits[~mask] = float("-inf")
        selected_slot = int(candidate_logits.argmax().item())
        selected_score = float(F.softmax(candidate_logits, dim=0)[selected_slot].item())
        selected_candidate_id = window.candidate_ids[frame_index][selected_slot]
        # candidate feature 的 x/y 已按完整模型输入帧归一化；保留该空间契约，
        # 后续评分可通过 candidate_id 回查原始视频像素，避免重复换算造成误差。
        selected_candidate_xy = [
            float(window.candidate_features[frame_index, selected_slot, 1].item()),
            float(window.candidate_features[frame_index, selected_slot, 2].item()),
        ]
    else:
        selected_slot = None
        selected_score = None
        selected_candidate_id = None
        selected_candidate_xy = None
    entropy = float((-(action_probs * action_probs.clamp_min(1e-9).log()).sum()).item())
    return {
        "version": DECISION_OUTPUT_VERSION,
        "sample_key": window.sample_keys[frame_index],
        "frame_index": window.frame_indices[frame_index],
        "timestamp_ms": window.timestamps_ms[frame_index],
        "action": ACTION_NAMES[action_id],
        "action_id": action_id,
        "action_probability": float(action_probs[action_id].item()),
        "selected_candidate_slot": selected_slot,
        "selected_candidate_id": selected_candidate_id,
        "selected_candidate_probability": selected_score,
        "selected_candidate_xy_normalized": selected_candidate_xy,
        "selected_candidate_xy_space": "model_input_normalized",
        # 模型直接回归的 x/y 同样以整帧为基准；消费方必须先还原视频像素，
        # 再通过当前样本的坐标变换映射到 osu! 空间。
        "predicted_xy_normalized": [
            float(output.x[0, 0].detach().cpu().item()),
            float(output.y[0, 0].detach().cpu().item()),
        ],
        "predicted_xy_space": "model_input_normalized",
        "time_offset_ms": float(output.time_offset_ms[0, 0].detach().cpu().item()),
        "diagnostics": {
            "action_probabilities": {
                name: float(action_probs[index].item())
                for index, name in enumerate(ACTION_NAMES)
            },
            "action_entropy": entropy,
            "action_margin": (
                float((top_probs[0] - top_probs[1]).item())
                if top_probs.numel() >= 2
                else 0.0
            ),
            "candidate_mask_count": int(mask.sum().item()),
            "has_candidate": bool(mask.any()),
        },
    }


def _decision_diagnostics(rows: list[dict[str, Any]]) -> dict[str, Any]:
    if not rows:
        return {
            "frame_count": 0,
            "action_probability_means": {},
            "entropy_mean": 0.0,
            "margin_mean": 0.0,
            "frames_with_candidate": 0,
        }
    probability_means = {}
    for name in ACTION_NAMES:
        probability_means[name] = sum(
            float(row["action_probabilities"].get(name, 0.0)) for row in rows
        ) / len(rows)
    return {
        "frame_count": len(rows),
        "action_probability_means": probability_means,
        "entropy_mean": sum(float(row["action_entropy"]) for row in rows) / len(rows),
        "margin_mean": sum(float(row["action_margin"]) for row in rows) / len(rows),
        "frames_with_candidate": sum(1 for row in rows if row["has_candidate"]),
        "candidate_mask_count_mean": sum(
            int(row["candidate_mask_count"]) for row in rows
        )
        / len(rows),
    }


__all__ = [
    "DECISION_OUTPUT_VERSION",
    "TemporalDecisionRunResult",
    "run_temporal_decision",
]
