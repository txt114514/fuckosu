"""运行空间推理并生成带时序监督、歧义信息和版本清单的候选缓存。"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from math import hypot
from pathlib import Path
from typing import Any
import json
import random

import torch

from traning.lib.training import (
    DEFAULT_CIRCLE_RADIUS_OSU_PIXELS,
    SliderPathCandidate,
)
from traning.lib.training.spatial_decode import SpatialCandidate
from traning.conf import DataSplit, Settings
from traning.core.dataset_import import build_dataset
from traning.core.spatial import (
    prepare_spatial_frame_inference,
    slider_path_to_dict,
    spatial_candidate_to_dict,
)
from traning.lib.coordinates import transform_from_settings_or_sample
from traning.state.candidate_cache_schema import (
    CANDIDATE_CACHE_VERSION,
    SUPPORTED_CANDIDATE_CACHE_VERSIONS,
)
from traning.state.versioning import version_manifest


@dataclass(frozen=True)
class CandidateCacheBuildResult:
    output_dir: Path
    manifest_path: Path
    records_path: Path
    device: str
    split: str
    frames: int
    candidates: int
    slider_paths: int
    ambiguous_candidates: int
    ambiguous_slider_paths: int
    diagnostics: Mapping[str, Any] | None = None

    def as_dict(self) -> dict[str, Any]:
        payload = {
            "output_dir": self.output_dir,
            "manifest_path": self.manifest_path,
            "records_path": self.records_path,
            "device": self.device,
            "split": self.split,
            "frames": self.frames,
            "candidates": self.candidates,
            "slider_paths": self.slider_paths,
            "ambiguous_candidates": self.ambiguous_candidates,
            "ambiguous_slider_paths": self.ambiguous_slider_paths,
        }
        if self.diagnostics is not None:
            payload["diagnostics"] = dict(self.diagnostics)
        return payload


def generate_candidate_cache(
    settings: Settings,
    *,
    output_dir: Path,
    device: torch.device,
    spatial_checkpoint_path: Path | None = None,
    split: DataSplit = "train",
    max_frames: int | None = None,
    patch_limit: int | None = None,
    max_candidates: int | None = None,
    score_threshold: float | None = None,
    nms_radius_px: float | None = None,
    slider_threshold: float | None = None,
    max_slider_paths: int | None = None,
    dataset: Sequence[Mapping[str, Any]] | None = None,
) -> CandidateCacheBuildResult:
    if max_frames is not None and max_frames <= 0:
        raise ValueError("max_frames must be positive when set")
    output_dir.mkdir(parents=True, exist_ok=True)
    records_path = output_dir / "frames.jsonl"
    manifest_path = output_dir / "manifest.json"

    cache = settings.candidate_cache
    selected_max_candidates = max_candidates or cache.max_candidates_per_frame
    selected_score_threshold = (
        cache.score_threshold if score_threshold is None else score_threshold
    )
    selected_nms_radius = (
        cache.nms_radius_px if nms_radius_px is None else nms_radius_px
    )
    selected_slider_threshold = (
        cache.slider_threshold if slider_threshold is None else slider_threshold
    )
    selected_max_slider_paths = max_slider_paths or cache.max_slider_paths

    source = dataset if dataset is not None else build_dataset(settings, split=split)
    frame_total = len(source) if max_frames is None else min(len(source), max_frames)
    if frame_total <= 0:
        raise ValueError("candidate cache dataset must not be empty")
    selected_indices = _candidate_cache_indices(
        source,
        frame_total=frame_total,
        seed=int(settings.runtime.seed),
        diverse=max_frames is not None,
        contiguous_block_frames=max(1, int(settings.temporal.history_frames)),
    )
    # 有限帧模式仍按样本组选择连续块，避免给时序阶段制造跨片段的伪连续窗口。

    total_candidates = 0
    total_slider_paths = 0
    ambiguous_candidates = 0
    ambiguous_slider_paths = 0
    frame_candidate_counts: list[int] = []
    candidate_scores: list[float] = []
    decode_threshold_counts: list[int] = []
    decode_nms_counts: list[int] = []
    target_frame_count = 0
    target_frames_with_any_candidate = 0
    target_frames_with_matched_candidate = 0
    recall_hits = {16: 0, 32: 0, 64: 0}
    inference_runner = prepare_spatial_frame_inference(
        settings,
        device=device,
        checkpoint_path=spatial_checkpoint_path,
    )
    with records_path.open("w", encoding="utf-8") as handle:
        for index in selected_indices:
            sample = source[index]
            result = inference_runner.infer_frame(
                sample,
                max_candidates=selected_max_candidates,
                score_threshold=selected_score_threshold,
                nms_radius_px=selected_nms_radius,
                slider_threshold=selected_slider_threshold,
                max_slider_paths=selected_max_slider_paths,
                slider_min_cells=cache.slider_min_cells,
                slider_path_points=cache.slider_path_points,
                patch_limit=patch_limit,
            )
            record = build_candidate_cache_record(
                sample,
                result.candidates,
                result.slider_paths,
                frame_width=int(sample["image"].shape[-1]),
                frame_height=int(sample["image"].shape[-2]),
                device=str(device),
                patches_processed=result.patches_processed,
                frame_channels=result.frame_channels,
                save_dtype=cache.save_dtype,
                low_confidence_threshold=cache.low_confidence_threshold,
                close_score_margin=cache.close_score_margin,
                slider_attach_distance_px=cache.slider_attach_distance_px,
                action_window_ms=max(1000.0 / settings.data_input.sample_fps / 2, 1.0),
                settings=settings,
            )
            diagnostics = getattr(result, "diagnostics", None)
            record["spatial_diagnostics"] = (
                diagnostics.as_dict()
                if diagnostics is not None
                else {
                    "threshold_candidate_count": len(record["candidates"]),
                    "nms_candidate_count": len(record["candidates"]),
                }
            )
            total_candidates += len(record["candidates"])
            frame_candidate_counts.append(len(record["candidates"]))
            candidate_scores.extend(
                float(candidate.get("score") or 0.0)
                for candidate in record["candidates"]
            )
            decode_threshold_counts.append(
                int(record["spatial_diagnostics"]["threshold_candidate_count"])
            )
            decode_nms_counts.append(
                int(record["spatial_diagnostics"]["nms_candidate_count"])
            )
            temporal_target = record.get("temporal_target")
            if (
                isinstance(temporal_target, Mapping)
                and str(temporal_target.get("action")) != "no_op"
            ):
                target_frame_count += 1
                if record["candidates"]:
                    target_frames_with_any_candidate += 1
                if temporal_target.get("selected_candidate_id") is not None:
                    target_frames_with_matched_candidate += 1
                distances = temporal_target.get("candidate_distances_px")
                if isinstance(distances, Sequence) and not isinstance(
                    distances, (str, bytes)
                ):
                    valid_distances = [
                        float(value)
                        for value in distances
                        if isinstance(value, int | float)
                    ]
                    if valid_distances:
                        nearest = min(valid_distances)
                        for radius in recall_hits:
                            if nearest <= radius:
                                recall_hits[radius] += 1
            total_slider_paths += len(record["slider_paths"])
            ambiguous_candidates += sum(
                1 for candidate in record["candidates"] if candidate["ambiguous"]
            )
            ambiguous_slider_paths += sum(
                1 for path in record["slider_paths"] if path["ambiguous"]
            )
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")

    diagnostics = {
        "frame_count": frame_total,
        "frames_with_candidate": sum(
            1 for count in frame_candidate_counts if count > 0
        ),
        "candidate_total": total_candidates,
        "candidate_per_frame_mean": _mean(frame_candidate_counts),
        "candidate_per_frame_p50": _percentile(frame_candidate_counts, 50),
        "candidate_per_frame_p95": _percentile(frame_candidate_counts, 95),
        "candidate_score_min": min(candidate_scores) if candidate_scores else None,
        "candidate_score_mean": _mean(candidate_scores),
        "candidate_score_max": max(candidate_scores) if candidate_scores else None,
        "raw_peaks_after_threshold_total": sum(decode_threshold_counts),
        "after_nms_total": sum(decode_nms_counts),
        "after_cache_serialization_total": total_candidates,
        "target_frame_count": target_frame_count,
        "target_frames_with_any_candidate": target_frames_with_any_candidate,
        "target_frames_with_candidate_near_target": target_frames_with_matched_candidate,
        # 下列是用于比较候选器的固定视频像素探针，不是
        # v2 的命中半径；真实匹配已在 osu 空间按 CircleSize 判定。
        "target_candidate_recall_probe_space": "video_px_fixed_threshold",
        "target_candidate_recall@16px": _rate(recall_hits[16], target_frame_count),
        "target_candidate_recall@32px": _rate(recall_hits[32], target_frame_count),
        "target_candidate_recall@64px": _rate(recall_hits[64], target_frame_count),
    }
    manifest = {
        "version": CANDIDATE_CACHE_VERSION,
        "versions": version_manifest(settings)
        | {"candidate_cache_version": CANDIDATE_CACHE_VERSION},
        "split": split,
        "device": str(device),
        "spatial_checkpoint_path": (
            str(spatial_checkpoint_path)
            if spatial_checkpoint_path is not None
            else None
        ),
        "spatial_inference_context": "reused_per_candidate_cache",
        "frames": frame_total,
        "sampling": {
            "mode": (
                "seeded_group_contiguous_round_robin"
                if max_frames is not None
                else "sequential_all"
            ),
            "seed": int(settings.runtime.seed),
            "contiguous_block_frames": max(1, int(settings.temporal.history_frames)),
            "selected_indices_preview": selected_indices[:100],
            "unique_sample_groups": len(
                _sample_groups_for_indices(source, selected_indices)
            ),
        },
        "records": str(records_path.name),
        "max_candidates_per_frame": selected_max_candidates,
        "score_threshold": selected_score_threshold,
        "nms_radius_px": selected_nms_radius,
        "slider_threshold": selected_slider_threshold,
        "max_slider_paths": selected_max_slider_paths,
        "save_dtype": cache.save_dtype,
        "candidate_count": total_candidates,
        "slider_path_count": total_slider_paths,
        "ambiguous_candidate_count": ambiguous_candidates,
        "ambiguous_slider_path_count": ambiguous_slider_paths,
        "diagnostics": diagnostics,
    }
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return CandidateCacheBuildResult(
        output_dir=output_dir,
        manifest_path=manifest_path,
        records_path=records_path,
        device=str(device),
        split=str(split),
        frames=frame_total,
        candidates=total_candidates,
        slider_paths=total_slider_paths,
        ambiguous_candidates=ambiguous_candidates,
        ambiguous_slider_paths=ambiguous_slider_paths,
        diagnostics=diagnostics,
    )


def _candidate_cache_indices(
    source: Sequence[Mapping[str, Any]],
    *,
    frame_total: int,
    seed: int,
    diverse: bool,
    contiguous_block_frames: int = 1,
) -> tuple[int, ...]:
    if not diverse or frame_total >= len(source):
        return tuple(range(frame_total))
    groups: dict[str, list[int]] = {}
    for index in range(len(source)):
        groups.setdefault(_source_group_key(source, index), []).append(index)
    rng = random.Random(seed)
    ordered_groups = sorted(groups)
    rng.shuffle(ordered_groups)
    for indices in groups.values():
        indices.sort()
    block_size = max(1, contiguous_block_frames)
    active_group_count = max(
        1, min(len(ordered_groups), max(1, frame_total // block_size))
    )
    active_groups = ordered_groups[:active_group_count]
    starts: dict[str, int] = {}
    positions: dict[str, int] = {}
    for group in active_groups:
        indices = groups[group]
        max_start = max(0, len(indices) - block_size)
        start = rng.randint(0, max_start) if max_start > 0 else 0
        starts[group] = start
        positions[group] = start
    selected: list[int] = []
    while len(selected) < frame_total and active_groups:
        progressed = False
        for group in tuple(active_groups):
            position = positions[group]
            indices = groups[group]
            if position >= len(indices):
                continue
            for _ in range(block_size):
                if position >= len(indices) or len(selected) >= frame_total:
                    break
                selected.append(indices[position])
                position += 1
                progressed = True
            positions[group] = position
            if (
                position >= len(indices)
                and starts[group] > 0
                and len(selected) < frame_total
            ):
                positions[group] = 0
                starts[group] = 0
            if len(selected) >= frame_total:
                break
        if not progressed:
            break
    return tuple(selected)


def _sample_groups_for_indices(
    source: Sequence[Mapping[str, Any]],
    indices: Sequence[int],
) -> tuple[str, ...]:
    return tuple(sorted({_source_group_key(source, index) for index in indices}))


def _source_group_key(source: Sequence[Mapping[str, Any]], index: int) -> str:
    references = getattr(source, "references", None)
    records = getattr(source, "records", None)
    if isinstance(references, Sequence) and isinstance(records, Sequence):
        reference = references[index]
        record = records[getattr(reference, "record_index")]
        return str(getattr(record, "key", index))
    sample = source[index]
    return str(sample.get("sample_key") or sample.get("segment_id") or index)


def build_candidate_cache_record(
    sample: Mapping[str, Any],
    candidates: Sequence[SpatialCandidate],
    slider_paths: Sequence[SliderPathCandidate],
    *,
    frame_width: int,
    frame_height: int,
    device: str,
    patches_processed: int,
    frame_channels: int,
    save_dtype: str,
    low_confidence_threshold: float,
    close_score_margin: float,
    slider_attach_distance_px: float,
    action_window_ms: float = 25.0,
    settings: Settings | None = None,
) -> dict[str, Any]:
    slider_rows = [slider_path_to_dict(path) for path in slider_paths]
    candidate_rows = []
    for index, candidate in enumerate(candidates):
        attached = _nearest_slider_path(
            candidate,
            slider_paths,
            max_distance=slider_attach_distance_px,
        )
        reasons = _candidate_ambiguity_reasons(
            index,
            candidates,
            attached,
            low_confidence_threshold=low_confidence_threshold,
            close_score_margin=close_score_margin,
        )
        row = spatial_candidate_to_dict(candidate)
        row.update(
            {
                "candidate_id": index,
                "embedding": _cast_embedding(candidate.embedding, save_dtype),
                "slider_path_id": (None if attached is None else attached.component_id),
                "ambiguous": bool(reasons),
                "ambiguity_reasons": reasons,
            }
        )
        candidate_rows.append(row)
    _apply_candidate_reviews(
        candidate_rows,
        slider_rows=slider_rows,
        frame_width=frame_width,
        frame_height=frame_height,
        enabled=bool(
            settings is not None and settings.candidate_cache.ambiguity_review_enabled
        ),
        max_candidates=(
            settings.candidate_cache.ambiguity_review_max_candidates
            if settings is not None
            else 0
        ),
    )
    _apply_local_refinement(
        candidate_rows,
        slider_rows=slider_rows,
        frame_width=frame_width,
        frame_height=frame_height,
        enabled=bool(
            settings is not None and settings.candidate_cache.local_refiner_enabled
        ),
        top_k=(
            settings.candidate_cache.local_refiner_top_k if settings is not None else 0
        ),
        radius_px=(
            settings.candidate_cache.local_refiner_radius_px
            if settings is not None
            else 0.0
        ),
    )
    transform, transform_spec = transform_from_settings_or_sample(
        settings,
        sample,
        frame_width=frame_width,
        frame_height=frame_height,
    )
    circle_radius_osu_pixels = _circle_radius_osu_pixels(sample)
    circle_radius_video_pixels = (
        None
        if transform_spec.transform_status == "unresolved"
        else transform.osu_radius_to_video(circle_radius_osu_pixels)
    )
    # 缓存是空间、时序、评分和图集之间的持久边界，必须随记录保存确切坐标规格。
    return {
        "version": CANDIDATE_CACHE_VERSION,
        "coordinate_transform": transform_spec.as_dict(),
        "sample_key": sample.get("sample_key"),
        "frame_index": sample.get("frame_index"),
        "timestamp_ms": sample.get("timestamp_ms"),
        "frame_width": frame_width,
        "frame_height": frame_height,
        "circle_radius_osu_pixels": circle_radius_osu_pixels,
        "circle_radius_video_pixels": circle_radius_video_pixels,
        "device": device,
        "patches_processed": patches_processed,
        "frame_channels": frame_channels,
        "temporal_target": _build_temporal_target(
            sample,
            candidate_rows,
            frame_width=frame_width,
            frame_height=frame_height,
            action_window_ms=action_window_ms,
            circle_radius_osu_pixels=circle_radius_osu_pixels,
            settings=settings,
        ),
        "candidates": candidate_rows,
        "slider_paths": slider_rows,
    }


def _build_temporal_target(
    sample: Mapping[str, Any],
    candidates: Sequence[Mapping[str, Any]],
    *,
    frame_width: int,
    frame_height: int,
    action_window_ms: float,
    circle_radius_osu_pixels: float,
    settings: Settings | None = None,
) -> dict[str, Any]:
    timestamp_ms = _optional_float(sample.get("timestamp_ms")) or 0.0
    target = _select_temporal_object(
        sample.get("hit_objects") or (),
        timestamp_ms=timestamp_ms,
        action_window_ms=action_window_ms,
    )
    if target is None:
        return {
            "target_strategy": "beatmap_action_v1",
            "target_strategy_version": "beatmap-action-v2",
            "action": "no_op",
            "action_id": 0,
            "selected_candidate_id": None,
            "time_offset_ms": 0.0,
        }
    transform, transform_spec = transform_from_settings_or_sample(
        settings,
        sample,
        frame_width=frame_width,
        frame_height=frame_height,
    )
    if transform_spec.transform_status == "unresolved":
        return {
            "target_strategy": "beatmap_action_v1",
            "target_strategy_version": "beatmap-action-v2",
            "coordinate_transform_version": transform_spec.version,
            "transform_status": transform_spec.transform_status,
            "action": target["action"],
            "action_id": target["action_id"],
            "selected_candidate_id": None,
            "candidate_match_radius_osu": circle_radius_osu_pixels,
            "candidate_match_radius_px": None,
            "candidate_match_status": "unmatched",
            "candidate_match_unmatched_reason": "coordinate_transform_unresolved",
            "candidate_count": len(candidates),
            "target_osu_xy": [float(target["x"]), float(target["y"])],
            "time_offset_ms": float(target["time_offset_ms"]),
            "object_type": target["object_type"],
            "source_index": target["source_index"],
            "object_start_ms": target["start_ms"],
            "object_end_ms": target["end_ms"],
        }
    # 候选原始位置保留视频像素供诊断；命中判定逆变换到 osu 空间，避免
    # affine 把圆映成椭圆后用平均像素半径近似造成边界误判。
    video_xy = transform.osu_to_video(target["x"], target["y"])
    candidate_match_radius_px = transform.osu_radius_to_video(circle_radius_osu_pixels)
    candidate, distances_px, distances_osu = _nearest_candidate(
        candidates,
        target_video_xy=video_xy,
        target_osu_xy=(float(target["x"]), float(target["y"])),
        transform=transform,
        max_distance_osu=circle_radius_osu_pixels,
    )
    unmatched_reason = None
    if candidate is None:
        unmatched_reason = (
            "no_candidates" if not candidates else "nearest_candidate_outside_radius"
        )
    return {
        "target_strategy": "beatmap_action_v1",
        "target_strategy_version": "beatmap-action-v2",
        "coordinate_transform_version": transform_spec.version,
        "action": target["action"],
        "action_id": target["action_id"],
        "selected_candidate_id": (
            None if candidate is None else candidate.get("candidate_id")
        ),
        "candidate_match_radius_osu": circle_radius_osu_pixels,
        "candidate_match_radius_px": candidate_match_radius_px,
        "candidate_match_space": "osu",
        "candidate_match_status": "matched" if candidate is not None else "unmatched",
        "candidate_match_unmatched_reason": unmatched_reason,
        "candidate_count": len(candidates),
        "candidate_distances_osu": distances_osu,
        "candidate_distances_px": distances_px,
        "target_video_xy": [float(video_xy[0]), float(video_xy[1])],
        "target_osu_xy": [float(target["x"]), float(target["y"])],
        "time_offset_ms": float(target["time_offset_ms"]),
        "object_type": target["object_type"],
        "source_index": target["source_index"],
        "object_start_ms": target["start_ms"],
        "object_end_ms": target["end_ms"],
    }


def _circle_radius_osu_pixels(sample: Mapping[str, Any]) -> float:
    """读取谱面真实命中半径；旧样本缺字段时才使用协议默认值。"""

    value = _optional_float(sample.get("circle_radius_osu_pixels"))
    if value is None or value <= 0:
        return DEFAULT_CIRCLE_RADIUS_OSU_PIXELS
    return value


def _select_temporal_object(
    objects: object,
    *,
    timestamp_ms: float,
    action_window_ms: float,
) -> dict[str, Any] | None:
    if not isinstance(objects, Sequence):
        return None
    targets = [
        target
        for item in objects
        if isinstance(item, Mapping)
        for target in (
            _temporal_target_for_object(
                item,
                timestamp_ms=timestamp_ms,
                action_window_ms=action_window_ms,
            ),
        )
        if target is not None
    ]
    if not targets:
        return None
    priority = {"press": 0, "release": 1, "hold": 2}
    # 同帧多个对象竞争时优先离散边界动作，再按时间距离和谱面顺序稳定决胜。
    return min(
        targets,
        key=lambda target: (
            priority[target["action"]],
            abs(float(target["time_offset_ms"])),
            int(target["source_index"] if target["source_index"] is not None else 0),
        ),
    )


def _temporal_target_for_object(
    item: Mapping[str, Any],
    *,
    timestamp_ms: float,
    action_window_ms: float,
) -> dict[str, Any] | None:
    start_ms = _optional_float(item.get("start_ms"))
    end_ms = _optional_float(item.get("end_ms"))
    if start_ms is None:
        return None
    if end_ms is None:
        end_ms = start_ms
    point = _object_osu_point(item)
    if point is None:
        return None
    kind = _object_kind(item)
    action = None
    boundary_ms = start_ms
    boundary_point = point
    repeat_boundaries = _repeat_boundaries(item, start_ms=start_ms, end_ms=end_ms)
    if abs(timestamp_ms - start_ms) <= action_window_ms:
        action = "press"
        boundary_ms = start_ms
    elif kind == "circle" and _is_release_frame(
        timestamp_ms,
        start_ms=start_ms,
        action_window_ms=action_window_ms,
    ):
        action = "release"
        boundary_ms = start_ms + _click_duration_ms(action_window_ms)
    elif kind == "slider" and repeat_boundaries:
        selected = min(
            repeat_boundaries,
            key=lambda item: (
                abs(timestamp_ms - item[0]),
                0 if item[1] == "press" else 1,
            ),
        )
        if abs(timestamp_ms - selected[0]) <= action_window_ms:
            action = selected[1]
            boundary_ms = selected[0]
            boundary_point = selected[2]
    elif (
        kind in {"slider", "spinner"} and abs(timestamp_ms - end_ms) <= action_window_ms
    ):
        action = "release"
        boundary_ms = end_ms
        if kind == "slider":
            boundary_point = _slider_tail_point(item) or point
    elif kind in {"slider", "spinner"} and start_ms < timestamp_ms < end_ms:
        action = "hold"
        boundary_ms = timestamp_ms
    if action is None:
        return None
    return {
        "action": action,
        "action_id": {"press": 1, "hold": 2, "release": 3}[action],
        "time_offset_ms": timestamp_ms - boundary_ms,
        "object_type": kind,
        "source_index": item.get("source_index"),
        "start_ms": start_ms,
        "end_ms": end_ms,
        "x": boundary_point[0],
        "y": boundary_point[1],
    }


def _click_duration_ms(action_window_ms: float) -> float:
    return max(action_window_ms, 1.0)


def _is_release_frame(
    timestamp_ms: float,
    *,
    start_ms: float,
    action_window_ms: float,
) -> bool:
    release_ms = start_ms + _click_duration_ms(action_window_ms)
    return abs(timestamp_ms - release_ms) <= action_window_ms


def _repeat_boundaries(
    item: Mapping[str, Any],
    *,
    start_ms: float,
    end_ms: float,
) -> tuple[tuple[float, str, tuple[float, float]], ...]:
    repeats_raw = _optional_float(item.get("repeats"))
    repeats = max(1, int(repeats_raw or 1))
    if repeats <= 1 or end_ms <= start_ms:
        return ()
    head = _object_osu_point(item)
    tail = _slider_tail_point(item)
    if head is None or tail is None:
        return ()
    span = end_ms - start_ms
    boundaries: list[tuple[float, str, tuple[float, float]]] = []
    for repeat_index in range(1, repeats):
        time_ms = start_ms + span * repeat_index / repeats
        point = tail if repeat_index % 2 == 1 else head
        boundaries.append((time_ms, "release", point))
        boundaries.append((time_ms, "press", point))
    return tuple(boundaries)


def _slider_tail_point(item: Mapping[str, Any]) -> tuple[float, float] | None:
    path = item.get("path")
    if isinstance(path, Sequence) and path:
        last = path[-1]
        if isinstance(last, Sequence) and len(last) >= 2:
            return float(last[0]), float(last[1])
    return _object_osu_point(item)


def _object_osu_point(item: Mapping[str, Any]) -> tuple[float, float] | None:
    if item.get("x") is not None and item.get("y") is not None:
        return float(item["x"]), float(item["y"])
    path = item.get("path")
    if isinstance(path, Sequence) and path:
        first = path[0]
        if isinstance(first, Sequence) and len(first) >= 2:
            return float(first[0]), float(first[1])
    kind = _object_kind(item)
    if kind == "spinner":
        return 256.0, 192.0
    return None


def _object_kind(item: Mapping[str, Any]) -> str:
    raw = str(item.get("type", "")).lower()
    if "slider" in raw:
        return "slider"
    if "spinner" in raw:
        return "spinner"
    return "circle"


def _nearest_candidate(
    candidates: Sequence[Mapping[str, Any]],
    *,
    target_video_xy: tuple[float, float],
    target_osu_xy: tuple[float, float],
    transform: Any,
    max_distance_osu: float,
) -> tuple[Mapping[str, Any] | None, list[float], list[float]]:
    if not candidates:
        return None, [], []
    distances_px: list[float] = []
    distances_osu: list[float] = []
    for candidate in candidates:
        video_x = _optional_float(candidate.get("x")) or 0.0
        video_y = _optional_float(candidate.get("y")) or 0.0
        osu_x, osu_y = transform.video_to_osu(video_x, video_y)
        distances_px.append(
            hypot(video_x - target_video_xy[0], video_y - target_video_xy[1])
        )
        distances_osu.append(hypot(osu_x - target_osu_xy[0], osu_y - target_osu_xy[1]))
    nearest_index = min(range(len(candidates)), key=distances_osu.__getitem__)
    if distances_osu[nearest_index] > max_distance_osu:
        return None, distances_px, distances_osu
    return candidates[nearest_index], distances_px, distances_osu


def _candidate_ambiguity_reasons(
    index: int,
    candidates: Sequence[SpatialCandidate],
    slider_path: SliderPathCandidate | None,
    *,
    low_confidence_threshold: float,
    close_score_margin: float,
) -> tuple[str, ...]:
    candidate = candidates[index]
    reasons: list[str] = []
    if candidate.score < low_confidence_threshold:
        reasons.append("low_confidence")
    if _has_close_neighbor(index, candidates, margin=close_score_margin):
        reasons.append("close_score")
    if candidate.object_type.startswith("slider"):
        if slider_path is None:
            reasons.append("missing_slider_path")
        elif slider_path.ambiguous:
            reasons.append("slider_path_ambiguous")
    return tuple(reasons)


def _apply_candidate_reviews(
    rows: list[dict[str, Any]],
    *,
    slider_rows: Sequence[Mapping[str, Any]],
    frame_width: int,
    frame_height: int,
    enabled: bool,
    max_candidates: int,
) -> None:
    if not enabled or max_candidates <= 0:
        return
    reviewed = 0
    for row in rows:
        reasons = tuple(row.get("ambiguity_reasons") or ())
        if not reasons:
            continue
        review = _review_candidate_locally(
            row,
            slider_rows=slider_rows,
            frame_width=frame_width,
            frame_height=frame_height,
        )
        row["ambiguity_review"] = {
            "reasons": reasons,
            "strategy": "local_consistency_model_v1",
            **review,
            "frame_bounds": [0, 0, frame_width, frame_height],
        }
        if review["resolved"]:
            unresolved = tuple(
                reason
                for reason in reasons
                if reason
                not in {
                    "low_confidence",
                    "close_score",
                    "slider_path_ambiguous",
                }
            )
            row["ambiguity_reasons"] = unresolved
            row["ambiguous"] = bool(unresolved)
        else:
            row["ambiguity_reasons"] = tuple(
                dict.fromkeys((*reasons, "local_review_unresolved"))
            )
            row["ambiguous"] = True
        reviewed += 1
        if reviewed >= max_candidates:
            break


def _apply_local_refinement(
    rows: list[dict[str, Any]],
    *,
    slider_rows: Sequence[Mapping[str, Any]],
    frame_width: int,
    frame_height: int,
    enabled: bool,
    top_k: int,
    radius_px: float,
) -> None:
    if not enabled or top_k <= 0 or radius_px <= 0:
        return
    ordered = sorted(
        rows,
        key=lambda row: (
            not bool(row.get("ambiguous")),
            -float(row.get("score") or 0.0),
        ),
    )
    for row in ordered[:top_k]:
        before = [float(row.get("x") or 0.0), float(row.get("y") or 0.0)]
        clamped = [
            min(max(before[0], 0.0), float(frame_width - 1)),
            min(max(before[1], 0.0), float(frame_height - 1)),
        ]
        after = _refined_candidate_xy(
            row,
            slider_rows=slider_rows,
            current_xy=(clamped[0], clamped[1]),
            radius_px=radius_px,
        )
        score = float(row.get("score") or 0.0)
        moved = after != tuple(before)
        refined_score = min(
            1.0,
            score + (0.03 if moved else 0.01) if row.get("ambiguous") else score,
        )
        row["local_refinement"] = {
            "strategy": "local_patch_consistency_refiner_v2",
            "triggered": True,
            "max_radius_px": radius_px,
            "before_xy": before,
            "after_xy": [after[0], after[1]],
            "before_score": score,
            "after_score": refined_score,
            "changed": moved or refined_score != score,
        }
        row["x"], row["y"], row["score"] = after[0], after[1], refined_score


def _review_candidate_locally(
    row: Mapping[str, Any],
    *,
    slider_rows: Sequence[Mapping[str, Any]],
    frame_width: int,
    frame_height: int,
) -> dict[str, Any]:
    x = _optional_float(row.get("x")) or 0.0
    y = _optional_float(row.get("y")) or 0.0
    in_frame = 0.0 <= x < frame_width and 0.0 <= y < frame_height
    local_score = _local_evidence_score(row)
    slider_path = _row_slider_path(row, slider_rows)
    slider_distance = None
    if slider_path is not None:
        slider_distance = _distance_to_polyline(
            (x, y),
            _polyline_from_row(slider_path),
        )
    reasons = tuple(row.get("ambiguity_reasons") or ())
    missing_path = "missing_slider_path" in reasons
    resolved = (
        in_frame
        and local_score >= 0.55
        and not missing_path
        and (slider_distance is None or slider_distance <= 48.0)
    )
    return {
        "resolved": resolved,
        "local_evidence_score": local_score,
        "in_frame": in_frame,
        "slider_distance_px": slider_distance,
        "decision": "accept" if resolved else "keep_ambiguous",
    }


def _local_evidence_score(row: Mapping[str, Any]) -> float:
    score = _optional_float(row.get("score")) or 0.0
    center = _optional_float(row.get("center_score")) or score
    visible = _optional_float(row.get("visible_score")) or score
    type_score = _optional_float(row.get("type_score")) or score
    slider = _optional_float(row.get("slider_score")) or score
    spinner = _optional_float(row.get("spinner_score")) or score
    object_type = str(row.get("object_type") or "")
    if object_type.startswith("slider"):
        type_evidence = max(type_score, slider)
    elif object_type.startswith("spinner"):
        type_evidence = max(type_score, spinner)
    else:
        type_evidence = type_score
    return min(
        1.0,
        max(0.0, 0.35 * score + 0.30 * center + 0.20 * visible + 0.15 * type_evidence),
    )


def _refined_candidate_xy(
    row: Mapping[str, Any],
    *,
    slider_rows: Sequence[Mapping[str, Any]],
    current_xy: tuple[float, float],
    radius_px: float,
) -> tuple[float, float]:
    if not str(row.get("object_type") or "").startswith("slider"):
        return current_xy
    slider_path = _row_slider_path(row, slider_rows)
    if slider_path is None:
        return current_xy
    head = _point_from_row(slider_path.get("head"))
    if head is not None and _point_distance(current_xy, head) <= radius_px:
        return head
    nearest = _nearest_polyline_point(current_xy, _polyline_from_row(slider_path))
    if nearest is not None and _point_distance(current_xy, nearest) <= radius_px:
        return nearest
    return current_xy


def _row_slider_path(
    row: Mapping[str, Any],
    slider_rows: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any] | None:
    path_id = row.get("slider_path_id")
    if path_id is None:
        return None
    for path in slider_rows:
        if path.get("component_id") == path_id:
            return path
    return None


def _point_from_row(value: Any) -> tuple[float, float] | None:
    if (
        isinstance(value, Sequence)
        and not isinstance(value, str | bytes)
        and len(value) >= 2
    ):
        return float(value[0]), float(value[1])
    return None


def _polyline_from_row(row: Mapping[str, Any]) -> tuple[tuple[float, float], ...]:
    raw = row.get("polyline")
    if not isinstance(raw, Sequence):
        return ()
    points = [_point_from_row(point) for point in raw if isinstance(point, Sequence)]
    return tuple(point for point in points if point is not None)


def _nearest_polyline_point(
    point: tuple[float, float],
    polyline: Sequence[tuple[float, float]],
) -> tuple[float, float] | None:
    if not polyline:
        return None
    if len(polyline) == 1:
        return polyline[0]
    best_point = polyline[0]
    best_distance = float("inf")
    for start, end in zip(polyline, polyline[1:]):
        candidate = _project_point_to_segment(point, start, end)
        distance = _point_distance(point, candidate)
        if distance < best_distance:
            best_distance = distance
            best_point = candidate
    return best_point


def _project_point_to_segment(
    point: tuple[float, float],
    start: tuple[float, float],
    end: tuple[float, float],
) -> tuple[float, float]:
    px, py = point
    ax, ay = start
    bx, by = end
    vx = bx - ax
    vy = by - ay
    length_squared = vx * vx + vy * vy
    if length_squared <= 1e-6:
        return start
    t = ((px - ax) * vx + (py - ay) * vy) / length_squared
    t = min(max(t, 0.0), 1.0)
    return ax + t * vx, ay + t * vy


def _has_close_neighbor(
    index: int,
    candidates: Sequence[SpatialCandidate],
    *,
    margin: float,
) -> bool:
    if margin <= 0:
        return False
    score = candidates[index].score
    return any(
        abs(score - candidate.score) <= margin
        for other, candidate in enumerate(candidates)
        if other != index
    )


def _nearest_slider_path(
    candidate: SpatialCandidate,
    paths: Sequence[SliderPathCandidate],
    *,
    max_distance: float,
) -> SliderPathCandidate | None:
    if not candidate.object_type.startswith("slider") or not paths:
        return None
    best_path: SliderPathCandidate | None = None
    best_distance = float("inf")
    for path in paths:
        distance = _distance_to_polyline((candidate.x, candidate.y), path.polyline)
        if distance < best_distance:
            best_distance = distance
            best_path = path
    if best_distance <= max_distance:
        return best_path
    return None


def _distance_to_polyline(
    point: tuple[float, float],
    polyline: Sequence[tuple[float, float]],
) -> float:
    if not polyline:
        return float("inf")
    if len(polyline) == 1:
        return _point_distance(point, polyline[0])
    return min(
        _point_to_segment_distance(point, start, end)
        for start, end in zip(polyline, polyline[1:])
    )


def _point_to_segment_distance(
    point: tuple[float, float],
    start: tuple[float, float],
    end: tuple[float, float],
) -> float:
    px, py = point
    ax, ay = start
    bx, by = end
    vx = bx - ax
    vy = by - ay
    length_squared = vx * vx + vy * vy
    if length_squared <= 1e-6:
        return _point_distance(point, start)
    t = ((px - ax) * vx + (py - ay) * vy) / length_squared
    t = min(max(t, 0.0), 1.0)
    return _point_distance(point, (ax + t * vx, ay + t * vy))


def _point_distance(
    first: tuple[float, float],
    second: tuple[float, float],
) -> float:
    return ((first[0] - second[0]) ** 2 + (first[1] - second[1]) ** 2) ** 0.5


def _mean(values: Sequence[float | int]) -> float | None:
    return sum(float(value) for value in values) / len(values) if values else None


def _percentile(values: Sequence[float | int], percentile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(float(value) for value in values)
    index = round((len(ordered) - 1) * percentile / 100.0)
    return ordered[min(max(index, 0), len(ordered) - 1)]


def _rate(count: int, total: int) -> float:
    return float(count) / float(total) if total > 0 else 0.0


def _cast_embedding(values: Sequence[float], save_dtype: str) -> list[float]:
    tensor = torch.tensor(tuple(values), dtype=torch.float32)
    if save_dtype == "float16":
        tensor = tensor.to(torch.float16).to(torch.float32)
    elif save_dtype != "float32":
        raise ValueError(f"unsupported candidate cache dtype: {save_dtype}")
    return [float(value) for value in tensor.tolist()]


def _optional_float(value: Any) -> float | None:
    if isinstance(value, int | float):
        return float(value)
    return None


__all__ = [
    "CANDIDATE_CACHE_VERSION",
    "SUPPORTED_CANDIDATE_CACHE_VERSIONS",
    "CandidateCacheBuildResult",
    "build_candidate_cache_record",
    "generate_candidate_cache",
]
